# This is the repo for [this site](https://www.weirdbandkid.tk)
You can use this code but must chage wording.

Feel free to contact me @weirdbandkid#6833 on Discord
